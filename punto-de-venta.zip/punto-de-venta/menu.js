// Menú de Mi Comalito: [nombre, categoría, precio]. El servidor lo carga solo si no hay productos.
const huevo=['huevo verde','huevo rojo','frijol con queso','calabazas a la mexicana','rajas con queso','papa con chorizo'];
const carne=['picadillo','deshebrada','chicharrón','bistec a la mexicana','puerco en salsa verde'];
exports.lista=()=>{const L=[],g=(cat,pref,pH,pC)=>{huevo.forEach(x=>L.push([`${pref} de ${x}`,cat,pH]));carne.forEach(x=>L.push([`${pref} de ${x}`,cat,pC]))};
 g('Gorditas','Gordita',16,17);g('Bocoles','Bocol',17,18);g('Tacos de maíz','Taco de maíz',16,17);g('Tacos de harina','Taco de harina',17,18);
 L.push(['Migadas (3 guisos a elegir)','Antojitos',85],['Quesadilla','Antojitos',15],['Big Quesadilla','Antojitos',40],['Plátano frito','Postres',35],['Pan dulce','Postres',15],
 ['Agua de jamaica 1 litro','Bebidas',45],['Agua de horchata 1 litro','Bebidas',45],['Agua de jamaica 1/2 litro','Bebidas',25],['Agua de horchata 1/2 litro','Bebidas',25],
 ['Café de olla','Bebidas',25],['Coca-Cola Normal 600 ml','Bebidas',30],['Coca-Cola Zero 600 ml','Bebidas',30],['Escuis 600 ml','Bebidas',28],['Avena taza','Bebidas',20],['Té','Bebidas',15],
 ['Entomatadas','Desayunos',150],['Enchiladas','Desayunos',150],['Chilaquiles verdes','Desayunos',160],['Chilaquiles rojos','Desayunos',160],['Omelet','Desayunos',120],['Huevos divorciados','Desayunos',120],['Huevos al gusto','Desayunos',90]);
 return L};
