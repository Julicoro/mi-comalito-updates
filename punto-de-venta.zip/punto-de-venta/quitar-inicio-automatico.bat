@echo off
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Punto de venta.lnk"
echo Listo. Ya no se enciende solo.
pause
