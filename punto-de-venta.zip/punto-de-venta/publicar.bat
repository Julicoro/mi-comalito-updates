@echo off
cd /d "%~dp0"
set /p N=Que cambio en esta version? 
node publicar.js "%N%"
pause
