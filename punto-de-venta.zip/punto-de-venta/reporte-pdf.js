// Genera el reporte de ventas en PDF (una hoja carta/A4) sin librerías externas.
const W=595,H=842,ROSA='0.898 0.157 0.478',CAFE='0.29 0.173 0.102',GRIS='0.54 0.42 0.33',CREMA='1 0.973 0.82',BLANCO='1 1 1';
const m=n=>'$'+(+n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
const fe=s=>String(s).split('-').reverse().join('/');
module.exports=(R,tipo,d,h)=>{
 const ops=[],r=R.resumen;
 const fill=(c,x,y,w,hh)=>ops.push(`${c} rg ${x.toFixed(1)} ${(H-y-hh).toFixed(1)} ${w.toFixed(1)} ${hh.toFixed(1)} re f`);
 const txt=(s,x,y,sz=10,b=0,c=CAFE,al='l')=>{s=String(s).replace(/[\u202f\u00a0]/g,' ').replace(/[^\x20-\xff]/g,'?');const w=s.length*sz*(b?.58:.53);
  ops.push(`BT /F${b?2:1} ${sz} Tf ${c} rg ${(al=='r'?x-w:al=='c'?x-w/2:x).toFixed(1)} ${(H-y).toFixed(1)} Td (${s.replace(/[\\()]/g,'\\$&')}) Tj ET`)};
 const barras=(rows,y0,mx,c)=>rows.forEach((x,i)=>{const y=y0+i*20;txt(x.l.slice(0,38),40,y+10,9);fill(c,235,y,Math.max(2,x.v/(mx||1)*185),13);txt(x.t,555,y+10,9,1,CAFE,'r')});
 fill(ROSA,0,0,W,78);txt('Mi Comalito',40,40,26,1,BLANCO);txt('Gorditas y algo más',40,58,11,0,BLANCO);
 txt({hoy:'Reporte del día',semana:'Reporte de la semana',mes:'Reporte del mes'}[tipo]||'Reporte de ventas',555,36,14,1,BLANCO,'r');
 txt(d==h?fe(d):`Del ${fe(d)} al ${fe(h)}`,555,56,10,0,BLANCO,'r');
 [['Ventas',m(r.ventas),ROSA],['Tickets',r.tickets,CAFE],['Ticket promedio',m(r.tickets?r.ventas/r.tickets:0),CAFE],['Productos vendidos',r.piezas,CAFE]]
  .forEach(([l,v,c],i)=>{const x=40+i*131;fill(CREMA,x,98,121,56);txt(l,x+10,115,9,0,GRIS);txt(v,x+10,140,15,1,c)});
 if(!r.tickets)txt('No hay ventas registradas en este periodo.',40,200,12,0,GRIS);
 else{
  const horas=R.dias.length<2,corto=R.dias.length>8;
  const serie=horas?R.horas.map(x=>({l:x.hora+'h',v:x.ventas})):[...R.dias].reverse().map(x=>({l:corto?x.dia.slice(8):x.dia.slice(8)+'/'+x.dia.slice(5,7),v:x.ventas}));
  txt(horas?'Ventas por hora':'Ventas por día',40,182,12,1);
  const mx=Math.max(...serie.map(s=>s.v))||1,n=serie.length,paso=515/n,bw=Math.min(36,paso*.7);
  serie.forEach((s,i)=>{const x=40+i*paso+(paso-bw)/2,bh=Math.max(2,s.v/mx*85);fill(ROSA,x,300-bh,bw,bh);txt(s.l,x+bw/2,312,7,0,GRIS,'c');if(n<=12)txt(m(s.v).replace('.00',''),x+bw/2,296-bh,7,0,CAFE,'c')});
  fill(GRIS,40,300,515,.5);
  txt('Lo que más se vende',40,345,12,1);
  barras(R.top.map(t=>({l:t.nombre,v:t.n,t:`${t.n} pzas  ${m(t.total)}`})),358,Math.max(...R.top.map(t=>t.n)),ROSA);
  txt('Ventas por categoría',40,585,12,1);
  const cs=R.categorias.slice(0,8);
  barras(cs.map(c=>({l:c.categoria,v:c.total,t:`${Math.round(c.total/(r.ventas||1)*100)}%  ${m(c.total)}`})),598,Math.max(...cs.map(c=>c.total)),CAFE);
  txt('Formas de pago:  '+['efectivo','tarjeta','transferencia'].map(k=>`${k} ${m((R.metodos.find(x=>x.metodo==k)||{total:0}).total)}`).join('   -   '),40,785,10);
 }
 txt('Generado el '+new Date().toLocaleString('es-MX'),40,826,8,0,GRIS);
 const cont=Buffer.from(ops.join('\n'),'latin1');
 const objs=['<</Type/Catalog/Pages 2 0 R>>','<</Type/Pages/Kids[3 0 R]/Count 1>>',
  `<</Type/Page/Parent 2 0 R/MediaBox[0 0 ${W} ${H}]/Resources<</Font<</F1 5 0 R/F2 6 0 R>>>>/Contents 4 0 R>>`,null,
  '<</Type/Font/Subtype/Type1/BaseFont/Helvetica/Encoding/WinAnsiEncoding>>','<</Type/Font/Subtype/Type1/BaseFont/Helvetica-Bold/Encoding/WinAnsiEncoding>>'];
 let out=Buffer.from('%PDF-1.4\n'),offs=[];
 objs.forEach((o,i)=>{offs.push(out.length);
  const body=o===null?Buffer.concat([Buffer.from(`<</Length ${cont.length}>>\nstream\n`),cont,Buffer.from('\nendstream')]):Buffer.from(o,'latin1');
  out=Buffer.concat([out,Buffer.from(`${i+1} 0 obj\n`),body,Buffer.from('\nendobj\n')])});
 const xr=out.length;
 return Buffer.concat([out,Buffer.from(`xref\n0 ${objs.length+1}\n0000000000 65535 f \n`+offs.map(o=>String(o).padStart(10,'0')+' 00000 n \n').join('')+`trailer<</Size ${objs.length+1}/Root 1 0 R>>\nstartxref\n${xr}\n%%EOF`)]);
};
