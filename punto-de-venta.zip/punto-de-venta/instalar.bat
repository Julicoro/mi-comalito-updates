@echo off
title Instalador - Punto de venta Mi Comalito
net session >nul 2>&1
if errorlevel 1 (
  echo.
  echo Haz clic derecho en este archivo y elige "Ejecutar como administrador".
  echo.
  pause
  exit /b
)
set "DESTINO=C:\punto-de-venta"
echo.
echo === Instalando el punto de venta en %DESTINO% ===
echo.
where node >nul 2>nul
if not errorlevel 1 goto nodeok
if exist "%~dp0instaladores\node*.msi" (
  echo Instalando Node.js, espera un momento...
  for %%F in ("%~dp0instaladores\node*.msi") do start /wait msiexec /i "%%~fF" /passive /norestart
  echo.
  echo Node.js instalado. CIERRA esta ventana y vuelve a ejecutar instalar.bat como administrador.
) else (
  echo No se encontro Node.js. Instalalo desde https://nodejs.org ^(version LTS^) y vuelve a ejecutar este archivo.
)
pause
exit /b
:nodeok
if /i "%~dp0"=="%DESTINO%\" goto copiado
echo Copiando archivos...
set "XF=datos.db datos.db-wal datos.db-shm"
if exist "%DESTINO%\config.json" set "XF=%XF% config.json"
robocopy "%~dp0." "%DESTINO%" /E /XD instaladores respaldos dist /XF %XF% >nul
:copiado
echo Configurando Windows: firewall, red privada y sin suspension...
netsh advfirewall firewall delete rule name="Punto de venta" >nul 2>&1
netsh advfirewall firewall add rule name="Punto de venta" dir=in action=allow protocol=TCP localport=3000 profile=any >nul
powershell -NoProfile -Command "Get-NetConnectionProfile | Where-Object {$_.NetworkCategory -eq 'Public'} | Set-NetConnectionProfile -NetworkCategory Private" >nul 2>&1
powercfg /change standby-timeout-ac 0 >nul 2>&1
powercfg /change hibernate-timeout-ac 0 >nul 2>&1
echo Creando accesos directos...
powershell -NoProfile -Command "$w=New-Object -ComObject WScript.Shell;$d=[Environment]::GetFolderPath('CommonDesktopDirectory');$s=$w.CreateShortcut($d+'\Punto de venta.lnk');$s.TargetPath='C:\punto-de-venta\iniciar.bat';$s.WorkingDirectory='C:\punto-de-venta';$s.Save();$e=[Environment]::GetFolderPath('CommonStartup');$t=$w.CreateShortcut($e+'\Punto de venta.lnk');$t.TargetPath='C:\punto-de-venta\iniciar.bat';$t.WorkingDirectory='C:\punto-de-venta';$t.WindowStyle=7;$t.Save()" >nul 2>&1
echo.
echo ===================================================
echo  Listo. El punto de venta se abrira ahora.
echo  - Se encendera solo cada vez que prendan la computadora.
echo  - En la caja: toca el engrane, arriba a la derecha, para la impresora y los datos del ticket.
echo ===================================================
echo.
start "" "C:\punto-de-venta\iniciar.bat"
pause
