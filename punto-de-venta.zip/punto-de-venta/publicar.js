// Se usa en TU laptop: prepara la actualización para subirla. Uso:  node publicar.js "qué cambió"
const fs=require('fs'),path=require('path'),crypto=require('crypto'),{execFileSync}=require('child_process');
const R=__dirname,DIST=path.join(R,'dist'),STAGE=path.join(DIST,'programa'),EXC=new Set(['datos.db','datos.db-wal','datos.db-shm','respaldos','config.json','dist','node_modules','.git','.vscode']);
const notas=process.argv.slice(2).join(' ').trim()||'Mejoras y correcciones';
const v=JSON.parse(fs.readFileSync(path.join(R,'version.json'),'utf8')),[a,b,c]=v.version.split('.').map(Number),nueva=`${a}.${b}.${c+1}`,fecha=new Date().toISOString().slice(0,10);
function copiar(de,a,top){fs.mkdirSync(a,{recursive:true});for(const e of fs.readdirSync(de,{withFileTypes:true})){if(top&&EXC.has(e.name))continue;const s=path.join(de,e.name),d=path.join(a,e.name);e.isDirectory()?copiar(s,d,false):fs.copyFileSync(s,d)}}
fs.rmSync(DIST,{recursive:true,force:true});copiar(R,STAGE,true);fs.writeFileSync(path.join(STAGE,'version.json'),JSON.stringify({version:nueva,fecha},null,2));
const zip=path.join(DIST,'punto-de-venta.zip');
if(process.platform==='win32')execFileSync('powershell',['-NoProfile','-Command',`Compress-Archive -Path '${STAGE}\\*' -DestinationPath '${zip}' -Force`]);else execFileSync('zip',['-qr',zip,'.'],{cwd:STAGE});
const sha256=crypto.createHash('sha256').update(fs.readFileSync(zip)).digest('hex');
fs.writeFileSync(path.join(DIST,'version.json'),JSON.stringify({version:nueva,fecha,notas,zip:'punto-de-venta.zip',sha256},null,2));
fs.writeFileSync(path.join(R,'version.json'),JSON.stringify({version:nueva},null,2));fs.rmSync(STAGE,{recursive:true,force:true});
console.log(`\nListo. Versión ${nueva}\nSube estos 2 archivos de la carpeta "dist" a tu repositorio de GitHub (reemplazando los anteriores):\n  - version.json\n  - punto-de-venta.zip\nDespués, en el negocio: ⚙️ > Actualizaciones > Buscar actualización.\n`);
