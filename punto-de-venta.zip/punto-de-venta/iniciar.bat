@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Primero instala Node.js LTS desde https://nodejs.org & pause & exit)
set PV_BAT=1
set ABRIR=--abrir
:inicio
node server.js %ABRIR%
set ABRIR=
echo.
echo El servidor se detuvo o se esta actualizando. Reiniciando en 5 segundos... (cierra esta ventana para salir)
timeout /t 5 >nul
goto inicio
