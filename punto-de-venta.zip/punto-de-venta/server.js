const http=require('http'),fs=require('fs'),path=require('path'),os=require('os');
const {DatabaseSync}=require('node:sqlite');
const db=new DatabaseSync(path.join(__dirname,'datos.db'));
db.exec(`PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS productos(id INTEGER PRIMARY KEY,nombre TEXT,categoria TEXT,precio REAL,costo REAL DEFAULT 0,activo INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS pedidos(id INTEGER PRIMARY KEY,mesa TEXT,mesero TEXT,estado TEXT DEFAULT 'abierto',creado TEXT,cerrado TEXT,total REAL DEFAULT 0,costo REAL DEFAULT 0,metodo TEXT);
CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY,pedido_id INTEGER,producto_id INTEGER,nombre TEXT,precio REAL,costo REAL,cantidad INTEGER,nota TEXT);`);
db.exec(`CREATE TABLE IF NOT EXISTS mesas(id INTEGER PRIMARY KEY,nombre TEXT UNIQUE,activa INTEGER DEFAULT 1)`);
db.exec(`CREATE TABLE IF NOT EXISTS cortes(id INTEGER PRIMARY KEY,creado TEXT,desde TEXT,hasta TEXT,tickets INTEGER,ventas REAL,piezas INTEGER,fondo REAL,contado REAL,detalle TEXT)`);
try{db.exec('ALTER TABLE pedidos ADD COLUMN corte_id INTEGER')}catch{}
try{db.exec('ALTER TABLE productos ADD COLUMN agotado INTEGER DEFAULT 0')}catch{}
for(const a of['ALTER TABLE pedidos ADD COLUMN pref TEXT','ALTER TABLE items ADD COLUMN persona INTEGER DEFAULT 0','ALTER TABLE pedidos ADD COLUMN personas TEXT','ALTER TABLE pedidos ADD COLUMN padre INTEGER','ALTER TABLE pedidos ADD COLUMN persona_nombre TEXT'])try{db.exec(a)}catch{}
db.exec(`CREATE TABLE IF NOT EXISTS ajustes(clave TEXT PRIMARY KEY,valor TEXT);CREATE TABLE IF NOT EXISTS bitacora(id INTEGER PRIMARY KEY,fecha TEXT,accion TEXT,detalle TEXT,quien TEXT)`);
let CFG={claveCorte:'cambiar-clave',actualizacion:{url:'',token:''},negocio:{nombre:'Mi Comalito',direccion:'',telefono:'',redes:'',mensaje:'Dios bendiga tus alimentos. Buen provecho.',codigo:'850',cortar:false}};try{Object.assign(CFG,JSON.parse(fs.readFileSync(path.join(__dirname,'config.json'),'utf8')))}catch{}
const now=()=>new Date(Date.now()-new Date().getTimezoneOffset()*6e4).toISOString().slice(0,19).replace('T',' ');
const q=(s,...a)=>db.prepare(s).all(...a), run=(s,...a)=>db.prepare(s).run(...a);
const pedido=id=>{const p=q('SELECT * FROM pedidos WHERE id=?',id)[0];if(p){p.items=q('SELECT * FROM items WHERE pedido_id=?',id);p.personas=JSON.parse(p.personas||'[]');p.reparto=reparto(p)}return p};
const recalc=id=>run('UPDATE pedidos SET total=(SELECT COALESCE(SUM(precio*cantidad),0) FROM items WHERE pedido_id=?),costo=(SELECT COALESCE(SUM(costo*cantidad),0) FROM items WHERE pedido_id=?) WHERE id=?',id,id,id);
// ---- Cuentas divididas por persona ----
// items.persona: 0 = sin asignar, -1 = compartido, 1..n = persona.  pedidos.personas = [{n,pagada,q,venta,metodo,total}]
const pers=p=>typeof p.personas=='string'?JSON.parse(p.personas||'[]'):(p.personas||[]),guardaPers=(id,a)=>run('UPDATE pedidos SET personas=? WHERE id=?',JSON.stringify(a),id),cents=n=>Math.round(n*100);
const activas=a=>a.map((x,i)=>({...x,num:i+1})).filter(x=>!x.q);
function reparto(p){const act=activas(pers(p)),N=act.length;if(!N)return[];const S=cents(p.items.filter(i=>i.persona==-1).reduce((s,i)=>s+i.precio*i.cantidad,0));
 return act.map((x,k)=>{const propio=cents(p.items.filter(i=>i.persona==x.num).reduce((s,i)=>s+i.precio*i.cantidad,0))/100,cuota=(Math.floor(S/N)+(k<S%N?1:0))/100;
  return{num:x.num,n:x.n,pref:x.pref||'',pagada:!!x.pagada,venta:x.venta||null,metodo:x.metodo||null,propio,cuota,total:x.pagada?x.total:+(propio+cuota).toFixed(2)}})}
const pedidoAbierto=id=>{const p=q("SELECT * FROM pedidos WHERE id=? AND estado IN ('abierto','cuenta')",id)[0];if(!p)throw Error('La cuenta ya no está disponible');return p};
const vacia=id=>{if(!q('SELECT 1 FROM items WHERE pedido_id=?',id).length){const p=q('SELECT personas FROM pedidos WHERE id=?',id)[0];run("UPDATE pedidos SET estado=?,cerrado=? WHERE id=? AND estado IN ('abierto','cuenta')",pers(p).some(x=>x.pagada)?'dividido':'cancelado',now(),id)}};
function cobrarSel(id,nums,sinAsig,metodo){const p=pedidoAbierto(id),a=pers(p),act=activas(a),N=act.length;
 const sel=act.filter(x=>(nums||[]).includes(x.num));if(!sel.length&&!sinAsig)throw Error('Elige a quién cobrar');if(sel.some(x=>x.pagada))throw Error('Esa persona ya pagó');
 const items=q('SELECT * FROM items WHERE pedido_id=?',id),comp=items.filter(i=>i.persona==-1),S=cents(comp.reduce((s,i)=>s+i.precio*i.cantidad,0));
 const cuota=x=>Math.floor(S/N)+(act.findIndex(y=>y.num==x.num)<S%N?1:0),own=x=>cents(items.filter(i=>i.persona==x.num).reduce((s,i)=>s+i.precio*i.cantidad,0));
 const sin=sinAsig?items.filter(i=>i.persona==0):[],tot=sel.reduce((s,x)=>s+own(x)+cuota(x),0)+cents(sin.reduce((s,i)=>s+i.precio*i.cantidad,0));
 if(tot<=0)throw Error('No hay nada que cobrar');
 const prop=items.filter(i=>sel.some(x=>x.num==i.persona)).concat(sin),met=metodo||'efectivo',nom=sel.length==1&&!sin.length?sel[0].n:'Varias personas';
 const hijo=Number(run("INSERT INTO pedidos(mesa,mesero,estado,creado,cerrado,total,costo,metodo,padre,persona_nombre) VALUES(?,?,'cerrado',?,?,?,0,?,?,?)",p.mesa,p.mesero,p.creado,now(),tot/100,met,id,nom).lastInsertRowid);
 const ins=(i,c)=>run('INSERT INTO items(pedido_id,producto_id,nombre,precio,costo,cantidad,nota,persona) VALUES(?,?,?,?,?,?,?,?)',hijo,i.producto_id,i.nombre,i.precio,i.costo,c,i.nota,i.persona);
 prop.forEach(i=>ins(i,i.cantidad));if(sel.length)comp.forEach(i=>ins(i,i.cantidad*sel.length/N));
 prop.forEach(i=>run('DELETE FROM items WHERE id=?',i.id));
 sel.forEach(x=>Object.assign(a[x.num-1],{pagada:1,venta:hijo,metodo:met,total:(own(x)+cuota(x))/100}));
 if(act.every(x=>a[x.num-1].pagada))run('DELETE FROM items WHERE pedido_id=? AND persona=-1',id);
 guardaPers(id,a);recalc(id);vacia(id);return pedido(hijo)}
// ---- Documentos de tickets (venta, mesa completa, pre-cuenta) ----
const frac=c=>{if(Math.abs(c-Math.round(c))<.005)return String(Math.round(c));for(let d=2;d<=10;d++){const n=c*d;if(Math.abs(n-Math.round(n))<.02)return Math.round(n)+'/'+d}return c.toFixed(2)};
function filas(items,total){const f=items.map(i=>({ct:frac(i.cantidad),desc:i.nombre+(i.persona==-1?' (parte)':''),imp:cents(i.precio*i.cantidad),nota:i.nota,comp:i.persona==-1})),diff=cents(total)-f.reduce((s,x)=>s+x.imp,0);
 if(f.length&&diff){const k=f.map(x=>x.comp).lastIndexOf(true);f[k>=0?k:f.length-1].imp+=diff}f.forEach(x=>x.imp/=100);return f}
const arts=items=>Math.round(items.filter(i=>i.persona!=-1).reduce((s,i)=>s+i.cantidad,0)+items.filter(i=>i.persona==-1).reduce((s,i)=>s+i.cantidad,0));
function junta(items){const mp=new Map();for(const i of items){const k=i.nombre+'|'+i.precio+'|'+(i.nota||''),e=mp.get(k)||{nombre:i.nombre,precio:i.precio,nota:i.nota,cantidad:0,persona:0};e.cantidad+=i.cantidad;mp.set(k,e)}return[...mp.values()].map(e=>({...e,cantidad:Math.round(e.cantidad*100)/100}))}
const pend=P=>P.reparto.length?P.reparto.filter(r=>!r.pagada).reduce((s,r)=>s+r.total,0)+P.items.filter(i=>i.persona==0).reduce((s,i)=>s+i.precio*i.cantidad,0):P.total;
function docVenta(id){const c=pedido(id);if(!c||c.estado!='cerrado')throw Error('Ese ticket no está disponible');
 return[{titulo:'TICKET DE VENTA',folio:c.id,fecha:c.cerrado,mesa:nm(c.mesa)+(c.persona_nombre?' · '+c.persona_nombre:''),quien:c.mesero,filas:filas(c.items,c.total),articulos:arts(c.items),total:c.total,pago:c.metodo}]}
function docMesa(id0){const id=(q('SELECT padre FROM pedidos WHERE id=?',id0)[0]||{}).padre||id0,p=pedido(id);if(!p)throw Error('Mesa no encontrada');
 const hs=q("SELECT id FROM pedidos WHERE padre=? AND estado='cerrado' ORDER BY id",id).map(r=>pedido(r.id));if(p.estado=='cerrado')hs.push(p);if(!hs.length)throw Error('Todavía no hay cobros en esta mesa');
 const total=hs.reduce((s,h)=>s+cents(h.total),0)/100,base={folio:p.id,fecha:hs[hs.length-1].cerrado,mesa:nm(p.mesa),quien:p.mesero,total};
 if(hs.length==1&&!hs[0].persona_nombre)return docVenta(hs[0].id);
 return[{...base,titulo:'MESA COMPLETA',secciones:hs.map(h=>({titulo:((h.persona_nombre||'Resto')+' · '+h.metodo).toUpperCase(),filas:filas(h.items,h.total),total:h.total})),articulos:arts(hs.flatMap(h=>h.items))}]}
function partesDe(P){const N=P.reparto.length,comp=P.items.filter(i=>i.persona==-1).map(i=>({...i,cantidad:i.cantidad/N}));
 const secs=P.reparto.filter(r=>!r.pagada).map(r=>{const own=P.items.filter(i=>i.persona==r.num),its=own.concat(comp);return{r,titulo:(r.n+(r.pref?' · '+r.pref:'')).toUpperCase(),its,filas:filas(its,r.total),total:r.total}});
 const sin=P.items.filter(i=>i.persona==0);if(sin.length){const t=sin.reduce((s,i)=>s+i.precio*i.cantidad,0);secs.push({r:null,titulo:'SIN ASIGNAR',its:sin,filas:filas(sin,t),total:t})}return secs}
function docPre(id,modo){const P=pedido(pedidoAbierto(id).id),base={titulo:'CUENTA',fecha:now(),quien:P.mesero,pref:P.pref};
 if(P.reparto.length){const secs=partesDe(P);
  if(modo=='personas')return secs.map(s=>({...base,pref:s.r?(s.r.pref||P.pref):P.pref,mesa:nm(P.mesa)+' · '+(s.r?s.r.n:'Sin asignar'),filas:s.filas,articulos:arts(s.its),total:s.total}));
  return[{...base,mesa:nm(P.mesa),secciones:secs.map(s=>({titulo:s.titulo,filas:s.filas,total:s.total})),articulos:arts(P.items),total:pend(P)}]}
 return[{...base,mesa:nm(P.mesa),filas:filas(junta(P.items),P.total),articulos:arts(P.items),total:P.total}]}
function docComanda(pid,ids){const p=q('SELECT * FROM pedidos WHERE id=?',pid)[0];if(!p)throw Error('Cuenta no encontrada');const ex=String(aj('cocina_excluir')??'Bebidas').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
 let its=q("SELECT i.*,COALESCE(pr.categoria,'') categoria FROM items i LEFT JOIN productos pr ON pr.id=i.producto_id WHERE i.pedido_id=?",pid);if(ids)its=its.filter(i=>ids.includes(i.id));
 its=junta(its.filter(i=>!ex.includes(i.categoria.toLowerCase())));if(!its.length)return[];
 return[{tipo:'comanda',mesa:nm(p.mesa),fecha:now(),quien:p.mesero,filas:its.map(i=>({ct:frac(i.cantidad),desc:i.nombre,nota:i.nota}))}]}
function comandaAuto(pid,ids){try{if(aj('comanda')==='0')return;const nombre=aj('impresora_cocina')||aj('impresora');if(!nombre&&!process.env.IMPRESORA_TEST)return;const docs=docComanda(pid,ids);if(!docs.length)return;
 enviar(require('./tickets').escpos(docs,negocio()),nombre).catch(e=>{errImp={msg:'No salió la comanda: '+e.message,ts:Date.now()}})}catch(e){errImp={msg:'No salió la comanda: '+e.message,ts:Date.now()}}}
function docCorte(id){const c=q('SELECT * FROM cortes WHERE id=?',id)[0];if(!c)throw Error('El corte no existe');c.detalle=JSON.parse(c.detalle);return{tipo:'corte',...c}}
const docPrueba=()=>({titulo:'TICKET DE PRUEBA',folio:1,fecha:now(),mesa:'Prueba de impresión',quien:'Caja',filas:[{ct:'2',desc:'Gordita de picadillo',imp:34,nota:'sin cebolla'},{ct:'1',desc:'Café de olla',imp:25,nota:''},{ct:'1',desc:'Plátano frito',imp:35,nota:''}],articulos:4,total:94,pago:'efectivo'});
const docsPara=b=>b.tipo=='comanda'?(()=>{const d=docComanda(+b.id);if(!d.length)throw Error('No hay productos para cocina en esta cuenta');return d})():b.tipo=='venta'?(Array.isArray(b.ids)&&b.ids.length?b.ids.flatMap(x=>docVenta(+x)):docVenta(+b.id)):b.tipo=='mesa'?docMesa(+b.id):b.tipo=='precuenta'?docPre(+b.id,b.modo):b.tipo=='corte'?[docCorte(+b.id)]:[docPrueba()];
const {execFile:ef}=require('child_process');
const listaImpresoras=()=>new Promise(ok=>{if(process.env.IMPRESORA_TEST)return ok([{nombre:'POS-58',def:true},{nombre:'Microsoft Print to PDF',def:false}]);if(process.platform!=='win32')return ok([]);
 ef('powershell',['-NoProfile','-Command','Get-CimInstance Win32_Printer | Select-Object Name,Default | ConvertTo-Json -Compress'],{windowsHide:true,timeout:10000},(e,o)=>{try{let j=JSON.parse(o);if(!Array.isArray(j))j=[j];ok(j.filter(x=>x&&x.Name).map(x=>({nombre:x.Name,def:!!x.Default})))}catch{ok([])}})});
const enviar=(buf,nombre)=>new Promise((ok,no)=>{if(process.env.IMPRESORA_TEST){fs.writeFileSync(process.env.IMPRESORA_TEST,buf);return ok()}
 if(process.platform!=='win32')return no(Error('La impresión directa solo funciona en Windows.'));const f=path.join(os.tmpdir(),'ticket-'+Date.now()+'.bin');fs.writeFileSync(f,buf);
 ef('powershell',['-NoProfile','-ExecutionPolicy','Bypass','-File',path.join(__dirname,'imprimir.ps1'),'-Impresora',nombre||aj('impresora')||'','-Archivo',f],{windowsHide:true,timeout:20000},(e,o,er)=>{fs.unlink(f,()=>{});const t=String(o||'').trim();
  if(e&&!t)return no(Error(String(er||e.message).trim().slice(0,200)));if(t&&t!=='OK')return no(Error(t));ok()})});
const negocio=()=>{let s={};try{s=JSON.parse(aj('negocio')||'{}')}catch{}return{...CFG.negocio,...s,corteDetalle:aj('corte_detalle')==='1'}};
function reiniciar(){setTimeout(()=>{if(process.env.PV_BAT!=='1'){try{require('child_process').spawn(process.execPath,[path.join(__dirname,'server.js'),...process.argv.slice(2).filter(x=>x!=='--abrir')],{detached:true,stdio:'ignore',cwd:__dirname,windowsHide:true}).unref()}catch{}}process.exit(0)},1200)}
const W="estado='cerrado' AND substr(cerrado,1,10) BETWEEN ? AND ?";
if(!q('SELECT COUNT(*) n FROM mesas')[0].n){for(let i=1;i<=15;i++)run('INSERT INTO mesas(nombre) VALUES(?)',String(i));run("INSERT INTO mesas(nombre) VALUES('Para llevar')")}
if(!q('SELECT COUNT(*) n FROM productos WHERE activo=1')[0].n)for(const[n,c,p]of require('./menu').lista())run('INSERT INTO productos(nombre,categoria,precio,costo) VALUES(?,?,?,0)',n,c,p);
let errImp=null;
const propias=new Set(['127.0.0.1','::1','::ffff:127.0.0.1']);for(const l of Object.values(os.networkInterfaces()))for(const i of l){propias.add(i.address);propias.add('::ffff:'+i.address)}
const SOLO_CAJA=new Set(['GET /turno','GET /cortes','POST /corte','POST /cobrar','POST /mover','POST /cancelar','POST /productos','POST /productos/borrar','GET /reporte','POST /mesas','POST /mesas/borrar','GET /info','POST /productos/agotado','POST /orden','GET /bitacora','GET /actualizacion','POST /actualizacion','POST /negocio','GET /negocio','POST /persona/quitar','GET /impresion','POST /impresion','POST /cobrar-personas','POST /asignar-todo']);
const aj=k=>(q('SELECT valor FROM ajustes WHERE clave=?',k)[0]||{}).valor,setAj=(k,v)=>run('INSERT INTO ajustes(clave,valor) VALUES(?,?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor',k,v);
const mm=n=>'$'+(+n).toFixed(2),nm=x=>/^\d+$/.test(x)?'Mesa '+x:x,log=(a,d,quien)=>run('INSERT INTO bitacora(fecha,accion,detalle,quien) VALUES(?,?,?,?)',now(),a,d,quien||'');
const ORDEN0=['Gorditas','Bocoles','Tacos de maíz','Tacos de harina','Antojitos','Desayunos','Bebidas','Postres'];
// USB (Windows): detecta unidades extraíbles y copia ahí una copia completa de la base de datos
const {execFile}=require('child_process');
const usbs=()=>new Promise(ok=>{if(process.env.USB_TEST)return ok([{id:process.env.USB_TEST,nombre:'PRUEBA',libre:5e9}]);if(process.platform!=='win32')return ok([]);
 execFile('powershell',['-NoProfile','-Command',"Get-CimInstance Win32_LogicalDisk | Where-Object {$_.DriveType -eq 2} | Select-Object DeviceID,VolumeName,FreeSpace | ConvertTo-Json -Compress"],{windowsHide:true,timeout:10000},(e,o)=>{
  try{let j=JSON.parse(o);if(!Array.isArray(j))j=[j];ok(j.filter(x=>x&&x.DeviceID).map(x=>({id:x.DeviceID,nombre:x.VolumeName||'',libre:x.FreeSpace||0})))}catch{ok([])}})});
function respaldarUSB(u){const dir=path.join(/^[A-Z]:$/i.test(u.id)?u.id+'\\':u.id,'Respaldos-MiComalito');fs.mkdirSync(dir,{recursive:true});
 const f=path.join(dir,'datos-'+now().replace(' ','_').replace(/:/g,'-')+'.db');db.exec(`VACUUM INTO '${f.replace(/\\/g,'/').replace(/'/g,"''")}'`);
 const l=fs.readdirSync(dir).filter(x=>/^datos-.*\.db$/.test(x)).sort();while(l.length>30)fs.unlinkSync(path.join(dir,l.shift()));
 setAj('ultimo_usb',now().slice(0,16)+' en '+u.id);return f}
const turno=()=>{const w="estado='cerrado' AND corte_id IS NULL",sub=`SELECT id FROM pedidos WHERE ${w}`;
 const r=q(`SELECT COUNT(*) tickets,COALESCE(SUM(total),0) ventas,MIN(cerrado) desde,MAX(cerrado) hasta FROM pedidos WHERE ${w}`)[0];
 r.piezas=q(`SELECT COALESCE(SUM(cantidad),0) n FROM items WHERE pedido_id IN (${sub})`)[0].n;
 r.metodos=q(`SELECT metodo,SUM(total) total,COUNT(*) n FROM pedidos WHERE ${w} GROUP BY metodo`);r.lista=q(`SELECT id,mesa,persona_nombre,total,metodo FROM pedidos WHERE ${w} ORDER BY id`);
 r.productos=q(`SELECT COALESCE(p.categoria,'Otros') categoria,i.nombre,SUM(i.cantidad) n,SUM(i.precio*i.cantidad) total FROM items i LEFT JOIN productos p ON p.id=i.producto_id WHERE i.pedido_id IN (${sub}) GROUP BY 1,2 ORDER BY 1,2`);
 r.piezas=+r.piezas.toFixed(2);r.productos.forEach(x=>x.n=+x.n.toFixed(2));r.abiertas=q("SELECT COUNT(*) n FROM pedidos WHERE estado IN ('abierto','cuenta')")[0].n;return r};
const api={
'GET /productos':()=>{let o=ORDEN0;try{o=JSON.parse(aj('orden'))||ORDEN0}catch{}const i=c=>{const k=o.indexOf(c);return k<0?99:k};
 return q('SELECT * FROM productos WHERE activo=1 ORDER BY nombre').sort((a,b)=>i(a.categoria)-i(b.categoria)||a.categoria.localeCompare(b.categoria))},
'POST /productos/agotado':b=>run('UPDATE productos SET agotado=? WHERE id=?',b.agotado?1:0,b.id),
'POST /orden':b=>setAj('orden',JSON.stringify((b.orden||[]).map(String))),
'GET /bitacora':()=>q('SELECT fecha,accion,detalle,quien FROM bitacora ORDER BY id DESC LIMIT 50'),
'POST /productos':b=>{if(!b.nombre||!(+b.precio>=0))throw Error('Faltan datos');
 if(b.id)run('UPDATE productos SET nombre=?,categoria=?,precio=?,costo=? WHERE id=?',b.nombre,b.categoria||'General',+b.precio,+b.costo||0,b.id);
 else run('INSERT INTO productos(nombre,categoria,precio,costo) VALUES(?,?,?,?)',b.nombre,b.categoria||'General',+b.precio,+b.costo||0)},
'POST /productos/borrar':b=>run('UPDATE productos SET activo=0 WHERE id=?',b.id),
'GET /turno':()=>turno(),
'GET /cortes':()=>q('SELECT id,creado,desde,hasta,tickets,ventas,fondo,contado FROM cortes ORDER BY id DESC LIMIT 60'),
'POST /corte':b=>{if(String(b.clave||'')!==String(CFG.claveCorte))throw Error('Contraseña incorrecta');const t=turno();if(!t.tickets)throw Error('No hay ventas para cortar');
 const id=Number(run('INSERT INTO cortes(creado,desde,hasta,tickets,ventas,piezas,fondo,contado,detalle) VALUES(?,?,?,?,?,?,?,?,?)',now(),t.desde,t.hasta,t.tickets,t.ventas,t.piezas,+b.fondo||0,(b.contado===''||b.contado==null)?null:+b.contado,JSON.stringify({metodos:t.metodos,productos:t.productos,lista:t.lista})).lastInsertRowid);
 run("UPDATE pedidos SET corte_id=? WHERE estado='cerrado' AND corte_id IS NULL",id);return{id}},
'POST /dividir':b=>{const p=pedidoAbierto(b.id);if(pers(p).length)throw Error('Esta cuenta ya está dividida');const n=Math.min(10,Math.max(2,+b.n||2));guardaPers(p.id,Array.from({length:n},(_,k)=>({n:'Persona '+(k+1),pagada:0})))},
'POST /persona/nueva':b=>{const p=pedidoAbierto(b.id),a=pers(p);if(a.some(x=>x.pagada))throw Error('Ya se cobró a alguien; no se pueden agregar personas.');if(a.length>=10)throw Error('Máximo 10 personas');
 a.push({n:String(b.nombre||'').slice(0,20)||'Persona '+(a.length+1),pagada:0});guardaPers(p.id,a)},
'POST /persona/nombre':b=>{const p=pedidoAbierto(b.id),a=pers(p),x=a[b.num-1];if(!x||x.q)throw Error('Persona no encontrada');x.n=String(b.nombre||'').trim().slice(0,20)||x.n;guardaPers(p.id,a)},
'POST /persona/quitar':b=>{const p=pedidoAbierto(b.id),a=pers(p),x=a[b.num-1];if(!x)throw Error('Persona no encontrada');if(a.some(y=>y.pagada))throw Error('Ya se cobró a alguien; no se puede quitar.');
 if(q('SELECT 1 FROM items WHERE pedido_id=? AND persona=?',p.id,b.num).length)throw Error('Esa persona tiene productos; pásalos a otra primero.');x.q=1;if(a.every(y=>y.q))a.length=0;guardaPers(p.id,a)},
'POST /item/persona':b=>{const p=pedidoAbierto(b.id),a=pers(p),ps=Number(b.persona),it=q('SELECT * FROM items WHERE id=? AND pedido_id=?',b.item,p.id)[0];if(!it)throw Error('Producto no encontrado');
 if(ps!==0&&ps!==-1&&(!a[ps-1]||a[ps-1].q||a[ps-1].pagada))throw Error('Esa persona no está disponible');const c=+b.cant;
 if(c>0&&c<it.cantidad){run('UPDATE items SET cantidad=cantidad-? WHERE id=?',c,it.id);run('INSERT INTO items(pedido_id,producto_id,nombre,precio,costo,cantidad,nota,persona) VALUES(?,?,?,?,?,?,?,?)',p.id,it.producto_id,it.nombre,it.precio,it.costo,c,it.nota,ps)}
 else run('UPDATE items SET persona=? WHERE id=?',ps,it.id)},
'POST /asignar-todo':b=>{const p=pedidoAbierto(b.id);run('UPDATE items SET persona=? WHERE pedido_id=? AND persona=0',Number(b.persona)||-1,p.id)},
'POST /cobrar-personas':b=>cobrarSel(b.id,b.personas,!!b.sin_asignar,b.metodo),
'GET /impresion':()=>({nombre:aj('impresora')||'',auto:aj('auto_imprimir')!=='0',comanda:aj('comanda')!=='0',cocina:aj('impresora_cocina')||'',excluir:aj('cocina_excluir')??'Bebidas',corteDetalle:aj('corte_detalle')==='1',err:errImp}),
'POST /impresion':b=>{setAj('impresora',String(b.nombre||''));setAj('auto_imprimir',b.auto?'1':'0');setAj('comanda',b.comanda===false?'0':'1');setAj('impresora_cocina',String(b.cocina||''));setAj('cocina_excluir',String(b.excluir??'Bebidas').slice(0,100));setAj('corte_detalle',b.corteDetalle?'1':'0');errImp=null},
'GET /abiertos':()=>q("SELECT id FROM pedidos WHERE estado IN ('abierto','cuenta') ORDER BY id").map(r=>pedido(r.id)),
'POST /pedido':b=>{for(const i of b.items){const pr=q('SELECT nombre,agotado FROM productos WHERE id=?',i.id)[0];if(pr&&pr.agotado)throw Error(pr.nombre+' está agotado')}const p=q("SELECT id FROM pedidos WHERE mesa=? AND estado IN ('abierto','cuenta')",b.mesa)[0];
 const act=p?pers(q('SELECT personas FROM pedidos WHERE id=?',p.id)[0]):[],nombres=Array.isArray(b.personas)?b.personas.slice(0,10):[];
 if(nombres.length>act.length&&act.some(x=>x.pagada))throw Error('Ya se cobró a alguien de esta mesa; no se pueden agregar personas.');
 for(const i of b.items){const ps=Number(i.persona)||0;if(ps>0&&ps<=act.length&&(act[ps-1].pagada||act[ps-1].q))throw Error('Esa persona ya pagó')}
 const id=p?p.id:Number(run('INSERT INTO pedidos(mesa,mesero,creado) VALUES(?,?,?)',b.mesa,b.mesero||'',now()).lastInsertRowid);
 nombres.forEach((n,k)=>{if(!act[k]){const o=n&&typeof n=='object';act[k]={n:String((o?n.n:n)||'').slice(0,20)||'Persona '+(k+1),pagada:0,pref:o&&['efectivo','tarjeta','transferencia'].includes(n.pref)?n.pref:''}}});if(act.length)guardaPers(id,act);
 const ids=[];
 for(const i of b.items){const pr=q('SELECT * FROM productos WHERE id=?',i.id)[0];let ps=Number(i.persona)||0;if(ps>act.length||ps<-1)ps=0;
  if(pr&&i.cantidad>0)ids.push(Number(run('INSERT INTO items(pedido_id,producto_id,nombre,precio,costo,cantidad,nota,persona) VALUES(?,?,?,?,?,?,?,?)',id,pr.id,pr.nombre,pr.precio,pr.costo,i.cantidad,i.nota||'',ps).lastInsertRowid))}
 run("UPDATE pedidos SET estado='abierto' WHERE id=?",id);recalc(id);comandaAuto(id,ids);return pedido(id)},
'POST /cuenta':b=>run("UPDATE pedidos SET estado='cuenta',pref=COALESCE(?,pref) WHERE id=?",['efectivo','tarjeta','transferencia'].includes(b.pref)?b.pref:null,b.id),
'POST /persona/metodo':b=>{const p=pedidoAbierto(b.id),a=pers(p),x=a[b.num-1];if(!x||x.q||x.pagada)throw Error('Persona no disponible');if(!['efectivo','tarjeta','transferencia'].includes(b.metodo))throw Error('Forma de pago no válida');x.pref=b.metodo;guardaPers(p.id,a)},
'GET /negocio':()=>negocio(),
'GET /actualizacion':()=>({url:aj('upd_url')||(CFG.actualizacion||{}).url||'',token:!!(aj('upd_token')||(CFG.actualizacion||{}).token)}),
'POST /actualizacion':b=>{setAj('upd_url',String(b.url||'').trim());if(b.token!==undefined&&b.token!==null)setAj('upd_token',String(b.token).trim())},
'POST /negocio':b=>setAj('negocio',JSON.stringify(Object.fromEntries(['nombre','direccion','telefono','redes','mensaje'].map(k=>[k,String(b[k]||'').slice(0,80)])))),
'POST /quitar':b=>{const it=q('SELECT i.*,p.mesa FROM items i JOIN pedidos p ON p.id=i.pedido_id WHERE i.id=? AND i.pedido_id=?',b.item,b.id)[0];if(it)log('Producto quitado',`${nm(it.mesa)} · ${it.cantidad} × ${it.nombre} · ${mm(it.precio*it.cantidad)}`,b.quien||'Caja');run("DELETE FROM items WHERE id=? AND pedido_id=? AND pedido_id IN (SELECT id FROM pedidos WHERE estado IN ('abierto','cuenta'))",b.item,b.id);recalc(b.id);
 vacia(b.id)},
'GET /mesas':()=>q("SELECT id,nombre FROM mesas WHERE activa=1 ORDER BY nombre LIKE '%llevar%',CAST(nombre AS INTEGER)=0,CAST(nombre AS INTEGER),nombre"),
'POST /mesas':b=>{const n=String(b.nombre||'').replace(/['"<>\\]/g,'').trim().slice(0,20);if(!n)throw Error('Escribe el nombre de la mesa');
 const e=q('SELECT id,activa FROM mesas WHERE nombre=?',n)[0];if(e&&e.activa)throw Error('Esa mesa ya existe');e?run('UPDATE mesas SET activa=1 WHERE id=?',e.id):run('INSERT INTO mesas(nombre) VALUES(?)',n)},
'POST /mesas/borrar':b=>{const t=q('SELECT nombre FROM mesas WHERE id=?',b.id)[0];if(t&&q("SELECT 1 FROM pedidos WHERE mesa=? AND estado IN ('abierto','cuenta')",t.nombre).length)throw Error('Esa mesa tiene una cuenta abierta. Cóbrala o muévela primero.');run('UPDATE mesas SET activa=0 WHERE id=?',b.id)},
'POST /mover':b=>{const p=q("SELECT * FROM pedidos WHERE id=? AND estado IN ('abierto','cuenta')",b.id)[0];if(!p)throw Error('La cuenta ya no está disponible');
 if(!q('SELECT 1 FROM mesas WHERE nombre=? AND activa=1',b.mesa).length)throw Error('Esa mesa no existe');
 const t=q("SELECT id FROM pedidos WHERE mesa=? AND estado IN ('abierto','cuenta') AND id!=?",b.mesa,p.id)[0];
 if(t&&(pers(p).length||pers(q('SELECT personas FROM pedidos WHERE id=?',t.id)[0]).length))throw Error('No se pueden unir cuentas divididas por persona.');
 if(t){run('UPDATE items SET pedido_id=? WHERE pedido_id=?',t.id,p.id);run('DELETE FROM pedidos WHERE id=?',p.id);run("UPDATE pedidos SET estado='abierto' WHERE id=?",t.id);recalc(t.id);log('Cuentas unidas',`${nm(p.mesa)} → ${nm(b.mesa)}`,'Caja');return{id:t.id}}
 run('UPDATE pedidos SET mesa=? WHERE id=?',b.mesa,p.id);log('Cuenta movida',`${nm(p.mesa)} → ${nm(b.mesa)}`,'Caja');return{id:p.id}},
'POST /cancelar':b=>{const p=q("SELECT * FROM pedidos WHERE id=? AND estado IN ('abierto','cuenta')",b.id)[0];if(!p)return;if(pers(p).some(x=>x.pagada))throw Error('Ya se cobró a alguien de esta mesa; cobra lo que falta.');run("UPDATE pedidos SET estado='cancelado',cerrado=? WHERE id=?",now(),b.id);log('Cuenta cancelada',`${nm(p.mesa)} · ${mm(p.total)}`,'Caja')},
'GET /info':()=>({urls:Object.values(os.networkInterfaces()).flat().filter(i=>i.family==='IPv4'&&!i.internal).map(i=>`http://${i.address}:3000/mesero.html`)}),
'POST /cobrar':b=>{const p0=q('SELECT * FROM pedidos WHERE id=?',b.id)[0],pend=p0?activas(pers(p0)).filter(x=>!x.pagada):[];if(pend.length)return cobrarSel(b.id,pend.map(x=>x.num),true,b.metodo);recalc(b.id);run("UPDATE pedidos SET estado='cerrado',cerrado=?,metodo=? WHERE id=?",now(),b.metodo||'efectivo',b.id);return pedido(b.id)},
'GET /reporte':(b,u)=>{const d=u.searchParams.get('desde'),h=u.searchParams.get('hasta'),sub=`SELECT id FROM pedidos WHERE ${W}`;
 const resumen=q(`SELECT COUNT(*) tickets,COALESCE(SUM(total),0) ventas FROM pedidos WHERE ${W}`,d,h)[0];
 resumen.piezas=q(`SELECT COALESCE(SUM(cantidad),0) n FROM items WHERE pedido_id IN (${sub})`,d,h)[0].n;
 return{resumen,
 metodos:q(`SELECT metodo,SUM(total) total FROM pedidos WHERE ${W} GROUP BY metodo`,d,h),
 dias:q(`SELECT substr(cerrado,1,10) dia,COUNT(*) tickets,SUM(total) ventas FROM pedidos WHERE ${W} GROUP BY dia ORDER BY dia DESC`,d,h),
 horas:q(`SELECT substr(cerrado,12,2) hora,SUM(total) ventas FROM pedidos WHERE ${W} GROUP BY hora ORDER BY hora`,d,h),
 top:q(`SELECT nombre,SUM(cantidad) n,SUM(precio*cantidad) total FROM items WHERE pedido_id IN (${sub}) GROUP BY nombre ORDER BY n DESC LIMIT 10`,d,h),
 categorias:q(`SELECT COALESCE(p.categoria,'Otros') categoria,SUM(i.cantidad) n,SUM(i.precio*i.cantidad) total FROM items i LEFT JOIN productos p ON p.id=i.producto_id WHERE i.pedido_id IN (${sub}) GROUP BY 1 ORDER BY total DESC`,d,h),
 tickets:q(`SELECT id,mesa,mesero,cerrado,total,metodo,persona_nombre FROM pedidos WHERE ${W} ORDER BY id DESC`,d,h)}}
};
const _rep=api['GET /reporte'];api['GET /reporte']=(b,u)=>{const R=_rep(b,u);R.top.forEach(x=>x.n=+x.n.toFixed(2));R.categorias.forEach(x=>x.n=+x.n.toFixed(2));R.resumen.piezas=+R.resumen.piezas.toFixed(2);return R};
// Respaldo diario automático en la carpeta "respaldos"
function respaldo(){try{const d=now().slice(0,10),dir=path.join(__dirname,'respaldos'),f=path.join(dir,`datos-${d}.db`);
 fs.mkdirSync(dir,{recursive:true});if(fs.existsSync(f))fs.unlinkSync(f);db.exec(`VACUUM INTO '${f.replace(/\\/g,'/')}'`)}catch(e){console.log('Respaldo falló:',e.message)}}
respaldo();setInterval(respaldo,36e5);
http.createServer((req,res)=>{const u=new URL(req.url,'http://x'),local=propias.has(req.socket.remoteAddress);
 if(!local&&['/caja.html','/reporte.pdf','/corte.pdf','/ticket.pdf','/ticket-mesa.pdf','/precuenta.pdf','/comanda.pdf'].includes(u.pathname)){res.writeHead(403,{'Content-Type':'text/html; charset=utf-8'});return res.end('<meta name=viewport content="width=device-width,initial-scale=1"><body style="font:20px sans-serif;text-align:center;padding:40px">🔒 Esta pantalla solo se puede abrir desde la computadora de la caja.')}
 if(u.pathname==='/reporte.pdf'){try{const d=u.searchParams.get('desde'),h=u.searchParams.get('hasta'),t=(u.searchParams.get('tipo')||'rango').replace(/\W/g,'');
  if(!/^\d{4}-\d\d-\d\d$/.test(d)||!/^\d{4}-\d\d-\d\d$/.test(h))throw Error('Fechas inválidas');
  const pdf=require('./reporte-pdf')(api['GET /reporte']({},u),t,d,h);
  res.writeHead(200,{'Content-Type':'application/pdf','Content-Disposition':`attachment; filename="ventas-${t}-${d}.pdf"`});res.end(pdf)}
  catch(e){res.writeHead(400);res.end('Error: '+e.message)}return}
 const TK={'/ticket.pdf':(id,u)=>u.searchParams.get('ids')?u.searchParams.get('ids').split(',').flatMap(x=>docVenta(+x)):docVenta(id),'/ticket-mesa.pdf':id=>docMesa(id),'/precuenta.pdf':(id,u)=>docPre(id,u.searchParams.get('modo')),'/comanda.pdf':id=>{const d=docComanda(id);if(!d.length)throw Error('No hay productos para cocina en esta cuenta');return d}};
 if(TK[u.pathname]){try{const docs=TK[u.pathname](+u.searchParams.get('id'),u);res.writeHead(200,{'Content-Type':'application/pdf','Content-Disposition':'inline; filename="ticket.pdf"'});res.end(require('./tickets').pdf(docs,negocio()))}
  catch(e){res.writeHead(400,{'Content-Type':'text/plain; charset=utf-8'});res.end('Error: '+e.message)}return}
 if(u.pathname==='/corte.pdf'){try{const c=q('SELECT * FROM cortes WHERE id=?',+u.searchParams.get('id'))[0];if(!c)throw Error('El corte no existe');c.detalle=JSON.parse(c.detalle);
  res.writeHead(200,{'Content-Type':'application/pdf','Content-Disposition':`attachment; filename="corte-${String(c.id).padStart(4,'0')}.pdf"`});res.end(require('./tickets').pdf([{tipo:'corte',...c}],negocio()))}
  catch(e){res.writeHead(400);res.end('Error: '+e.message)}return}
 if(u.pathname==='/api/version'||u.pathname.startsWith('/api/actualizar/')){const jr=(c,o)=>{res.writeHead(c,{'Content-Type':'application/json'});res.end(JSON.stringify(o))};if(!local)return jr(403,{error:'Solo se puede hacer desde la computadora de la caja'});
  const A=require('./actualizar');if(u.pathname==='/api/version')return jr(200,{version:A.version(),anterior:A.hayAnterior()});
  const ch=[];let tam=0;req.on('data',c=>{tam+=c.length;if(tam<60e6)ch.push(c)});req.on('end',async()=>{try{if(tam>=60e6)throw Error('El archivo es demasiado grande.');const url=aj('upd_url')||(CFG.actualizacion||{}).url||'',tok=aj('upd_token')||(CFG.actualizacion||{}).token||'';
   if(u.pathname==='/api/actualizar/buscar')return jr(200,await A.buscar(url,tok));
   if(u.pathname==='/api/actualizar/web'){const i=await A.buscar(url,tok);if(!i.hay)throw Error('Ya tienes la versión más reciente.');const r=await A.aplicar(await A.bajar(new URL(i.zip,url).href,tok),{sha256:i.sha256});jr(200,r);return reiniciar()}
   if(u.pathname==='/api/actualizar/archivo'){const r=await A.aplicar(Buffer.concat(ch),{});jr(200,r);return reiniciar()}
   if(u.pathname==='/api/actualizar/revertir'){const r=A.revertir();jr(200,r);return reiniciar()}
   jr(404,{error:'No existe'})}catch(e){jr(400,{error:e.message})}});return}
 if(u.pathname==='/api/impresoras'||u.pathname==='/api/imprimir'){const jr=(c,o)=>{res.writeHead(c,{'Content-Type':'application/json'});res.end(JSON.stringify(o))};if(!local)return jr(403,{error:'Solo se puede hacer desde la computadora de la caja'});
  if(u.pathname==='/api/impresoras')return listaImpresoras().then(l=>jr(200,{impresoras:l}));
  let s='';req.on('data',c=>s+=c);req.on('end',()=>{try{const b=s?JSON.parse(s):{};enviar(require('./tickets').escpos(docsPara(b),negocio())).then(()=>jr(200,{ok:1}),e=>jr(400,{error:e.message}))}catch(e){jr(400,{error:e.message})}});return}
 if(u.pathname==='/api/usb'||u.pathname==='/api/respaldo-usb'){const jr=(c,o)=>{res.writeHead(c,{'Content-Type':'application/json'});res.end(JSON.stringify(o))};
  if(!local)return jr(403,{error:'Solo se puede hacer desde la computadora de la caja'});
  usbs().then(l=>{if(u.pathname==='/api/usb')return jr(200,{unidades:l,ultimo:aj('ultimo_usb')||''});
   if(!l.length)return jr(400,{error:'No encontré ninguna USB conectada.'});try{respaldarUSB(l[0]);jr(200,{ok:1,unidad:l[0].id})}catch(e){jr(400,{error:'No se pudo copiar a la USB: '+e.message})}});return}
 if(u.pathname.startsWith('/api/')){let s='';req.on('data',c=>s+=c);req.on('end',()=>{try{
  const k=req.method+' '+u.pathname.slice(4);if(!local&&SOLO_CAJA.has(k))throw Error('Solo se puede hacer desde la computadora de la caja');const f=api[k];if(!f)throw Error('No existe');
  const r=f(s?JSON.parse(s):{},u);res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify(r??{ok:1}))
 }catch(e){res.writeHead(400,{'Content-Type':'application/json'});res.end(JSON.stringify({error:e.message}))}});return}
 const f=path.join(__dirname,'public',u.pathname==='/'?'index.html':path.normalize(u.pathname).replace(/^(\.\.[\/\\])+/,''));
 fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);return res.end('No encontrado')}res.writeHead(200,{'Content-Type':({'.js':'text/javascript; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml'})[path.extname(f).toLowerCase()]||'text/html; charset=utf-8'});res.end(d)})
}).listen(3000,'0.0.0.0',()=>{if(process.platform==='win32'&&process.argv.includes('--abrir'))require('child_process').exec('start "" http://localhost:3000/caja.html');console.log('\nPunto de venta listo.\nCaja (esta computadora): http://localhost:3000/caja.html');
 for(const l of Object.values(os.networkInterfaces()))for(const i of l)if(i.family==='IPv4'&&!i.internal)console.log('Tablets de meseros:      http://'+i.address+':3000/mesero.html')});
