// Agrega al sistema los productos del menú que falten. Se puede correr varias veces: no duplica nada.
const {DatabaseSync}=require('node:sqlite'),path=require('path');
const db=new DatabaseSync(path.join(__dirname,'datos.db'));
db.exec(`CREATE TABLE IF NOT EXISTS productos(id INTEGER PRIMARY KEY,nombre TEXT,categoria TEXT,precio REAL,costo REAL DEFAULT 0,activo INTEGER DEFAULT 1)`);
const L=require('./menu').lista();let n=0;
for(const [nom,cat,pre] of L){if(db.prepare('SELECT 1 FROM productos WHERE nombre=? AND activo=1').all(nom).length)continue;db.prepare('INSERT INTO productos(nombre,categoria,precio,costo) VALUES(?,?,?,0)').run(nom,cat,pre);n++}
console.log(`Listo: ${n} productos agregados (${L.length-n} ya existían).`);
