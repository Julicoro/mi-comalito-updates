@echo off
set "LNK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Punto de venta.lnk"
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%LNK%');$s.TargetPath='%~dp0iniciar.bat';$s.WorkingDirectory='%~dp0';$s.WindowStyle=7;$s.Save()"
echo.
echo Listo. El punto de venta se encendera solo cada vez que inicies sesion en esta computadora.
pause
