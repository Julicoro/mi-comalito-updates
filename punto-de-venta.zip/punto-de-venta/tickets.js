// Tickets para impresora térmica de 58 mm (32 columnas). Un solo diseño, dos salidas:
//  - pdf():    para ver / reimprimir desde el navegador
//  - escpos(): bytes ESC/POS para mandar directo a la impresora
const fs=require('fs'),path=require('path'),zlib=require('zlib');
let LOGO=null;try{LOGO=JSON.parse(fs.readFileSync(path.join(__dirname,'logo-ticket.json'),'utf8'))}catch{}
const COLS={n:32,s:42,d:16};
const m=n=>(n<0?'-':'')+'$'+Math.abs(+n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
const fh=s=>{if(!s)return['',''];const[d,t]=s.split(' ');return[d.split('-').reverse().join('/'),(t||'').slice(0,5)]};
const U=['','UNO','DOS','TRES','CUATRO','CINCO','SEIS','SIETE','OCHO','NUEVE','DIEZ','ONCE','DOCE','TRECE','CATORCE','QUINCE','DIECISEIS','DIECISIETE','DIECIOCHO','DIECINUEVE','VEINTE','VEINTIUNO','VEINTIDOS','VEINTITRES','VEINTICUATRO','VEINTICINCO','VEINTISEIS','VEINTISIETE','VEINTIOCHO','VEINTINUEVE'];
const D=['','','','TREINTA','CUARENTA','CINCUENTA','SESENTA','SETENTA','OCHENTA','NOVENTA'],CE=['','CIENTO','DOSCIENTOS','TRESCIENTOS','CUATROCIENTOS','QUINIENTOS','SEISCIENTOS','SETECIENTOS','OCHOCIENTOS','NOVECIENTOS'];
const m1000=n=>{if(n==100)return'CIEN';let s=CE[Math.floor(n/100)];const r=n%100;if(r<30)s+=(s&&r?' ':'')+U[r];else s+=(s?' ':'')+D[Math.floor(r/10)]+(r%10?' Y '+U[r%10]:'');return s};
const letra=n=>{const e=Math.floor(n+1e-9),c=Math.round((n-e)*100);let s;if(!e)s='CERO';else{const mil=Math.floor(e/1000),r=e%1000;s=(mil?(mil==1?'MIL':m1000(mil).replace(/UNO$/,'UN')+' MIL'):'')+(mil&&r?' ':'')+(r?m1000(r):'')}
 s=e==1?'UN':s.replace(/UNO$/,'UN');return`${s} ${e==1?'PESO':'PESOS'} ${String(c).padStart(2,'0')}/100 M.N.`};
const wrap=(t,n)=>{const o=[];let l='';for(const w of String(t).split(' ')){if((l+' '+w).trim().length>n){if(l)o.push(l);l=w}else l=(l+' '+w).trim()}if(l)o.push(l);return o};
exports.letra=letra;
// ---- Diseño: lista de líneas {t,b,al,sz}  sz: n=normal, s=chica, d=doble ----
function lineas(d,cfg){cfg=cfg||{};const L=[],line=(t='',b=0,al='l',sz='n')=>L.push({t:String(t),b,al,sz}),sep=c=>line((c||'-').repeat(32));
 const row=(a,b,bo=0,sz='n')=>{const n=COLS[sz];a=String(a);b=String(b);line(a.slice(0,n-b.length-1).padEnd(n-b.length)+b,bo,'l',sz)};
 const item=(ct,desc,imp,izq)=>wrap(desc,18).forEach((t,k)=>line(k?'    '+t:(izq?String(ct).padEnd(3):String(ct).padStart(3))+' '+t.padEnd(18)+m(imp).padStart(10)));
 const cap=s=>s?s[0].toUpperCase()+s.slice(1):'',nm=x=>/^\d+$/.test(x)?'Mesa '+x:x;
 if(d.tipo=='comanda'){const h=fh(d.fecha)[1];line('COMANDA',1,'c','d');sep('=');line(String(d.mesa).slice(0,16),1,'c','d');line(h+(d.quien?'  ·  '+d.quien:''),0,'c');sep('=');
  for(const x of d.filas){wrap(x.ct+'  '+x.desc,32).forEach(t=>line(t,1));if(x.nota)wrap('» '+x.nota,28).forEach(t=>line('    '+t,1));line()}
  sep('=');line();return{L,logo:false}}
 if(d.tipo=='corte'){const D=d.detalle,a=fh(d.desde),b=fh(d.creado);line(cfg.nombre||'MI COMALITO',1,'c');line('Gorditas y algo más',0,'c');sep('=');line('CORTE DE CAJA #'+String(d.id).padStart(4,'0'),1,'c');sep('=');
  row('Apertura:',a[0]+' '+a[1]);row('Cierre:',b[0]+' '+b[1]);row('Tickets:',d.tickets);
  for(const k of['efectivo','tarjeta','transferencia']){const x=D.metodos.find(z=>z.metodo==k)||{total:0,n:0};sep('=');line(k.toUpperCase(),1,'c');
   if(cfg.corteDetalle&&D.lista)D.lista.filter(t=>t.metodo==k).forEach(t=>row('#'+String(t.id).padStart(4,'0')+' '+(t.persona_nombre?t.mesa+'·'+t.persona_nombre:nm(t.mesa)),m(t.total)));
   row('Total'+(x.n!=null?' ('+x.n+' tk)':''),m(x.total),1)}
  sep('=');row('TOTAL VENTAS',m(d.ventas),1);sep();line('PRODUCTOS VENDIDOS',1);let cat=null;D.productos.forEach(p=>{if(p.categoria!==cat){cat=p.categoria;line(cat.toUpperCase(),1)}item(p.n,p.nombre,p.total)});
  sep();row('Total piezas',d.piezas,1);line();line('Firma: __________________',0,'c');line('Impreso '+fh(d.creado)[0],0,'c','s');return{L,logo:false}}
 [cfg.direccion,cfg.telefono,cfg.redes].filter(Boolean).forEach(t=>wrap(t,32).forEach(x=>line(x,0,'c')));
 sep('=');line(d.titulo,1,'c');sep('=');const[f,h]=fh(d.fecha);
 if(d.folio)row('Folio: '+String(d.folio).padStart(4,'0'),f);else row('Fecha:',f);row(d.mesa,h+(d.folio?' hrs':''));if(d.quien)line('Atendió: '+d.quien);if(d.pref&&d.titulo=='CUENTA')row('Pagará con:',cap(d.pref));sep();
 line('CT DESCRIPCIÓN'.padEnd(25)+'IMPORTE',1);sep();
 const filas=fs=>{for(const x of fs){item(x.ct,x.desc,x.imp,true);if(x.nota)line('    » '+x.nota,0,'l','s')}};
 if(d.secciones)d.secciones.forEach((s,k)=>{if(k){sep();line()}line(s.titulo,1,'l');sep();filas(s.filas);row('Subtotal',m(s.total),1)});else filas(d.filas);
 sep();if(d.articulos!=null)row('Artículos: '+d.articulos,'');row('TOTAL',m(d.total),1,'d');
 if(d.titulo!='CUENTA')wrap('('+letra(d.total)+')',40).forEach(t=>line(t,1,'c','s'));sep();
 if(d.pagos){line('PAGOS',1);d.pagos.forEach(p=>row(p.n+' ('+p.m+')',m(p.t)));row('Total pagado',m(d.total),1)}else if(d.pago)row('Forma de pago:',String(d.pago).toUpperCase(),1);
 if(d.pagos||d.pago)sep('=');
 if(d.titulo=='CUENTA'){line();line('Este ticket no es comprobante',0,'c','s');line('de pago',0,'c','s')}
 else{line('¡Gracias por tu visita!',1,'c');wrap(cfg.mensaje||'',32).forEach(t=>line(t,0,'c'));line('Ticket sin validez fiscal',0,'c','s')}
 return{L,logo:!!LOGO}}
// ---- Salida PDF (58 mm = 164 pt) ----
const SZ={n:7.5,s:5.8,d:15},PW=164,MX=10;
function pagina(doc,cfg){const{L,logo}=lineas(doc,cfg),lw=113,lh=logo?Math.round(lw*LOGO.h/LOGO.w):0;let y=10+(lh?lh+8:0);const pos=[];
 for(const l of L){const sz=SZ[l.sz];y+=sz*1.3;const w=l.t.length*sz*.6;pos.push([l,sz,l.al=='c'?(PW-w)/2:MX,y])}
 const H=Math.ceil(y+24),ops=[];if(lh)ops.push(`q ${lw} 0 0 ${lh} ${(PW-lw)/2} ${H-10-lh} cm /Im1 Do Q`);
 for(const[l,sz,x,yy]of pos)if(l.t.trim())ops.push(`BT /F${l.b?2:1} ${sz} Tf 0 g ${x.toFixed(1)} ${(H-yy).toFixed(1)} Td (${l.t.replace(/[^\x20-\xff]/g,'?').replace(/[\\()]/g,'\\$&')}) Tj ET`);
 return{H,ops}}
exports.pdf=(docs,cfg)=>{const pages=docs.map(d=>pagina(d,cfg)),objs=[],add=b=>{objs.push(Buffer.isBuffer(b)?b:Buffer.from(b,'latin1'));return objs.length};
 add('<</Type/Catalog/Pages 2 0 R>>');add('x');add('<</Type/Font/Subtype/Type1/BaseFont/Courier/Encoding/WinAnsiEncoding>>');add('<</Type/Font/Subtype/Type1/BaseFont/Courier-Bold/Encoding/WinAnsiEncoding>>');
 let img=0;if(LOGO){const z=zlib.deflateSync(Buffer.from(LOGO.data,'base64'));img=add(Buffer.concat([Buffer.from(`<</Type/XObject/Subtype/Image/Width ${LOGO.w}/Height ${LOGO.h}/ColorSpace/DeviceGray/BitsPerComponent 1/Filter/FlateDecode/Length ${z.length}>>\nstream\n`),z,Buffer.from('\nendstream')]))}
 const kids=[];for(const pg of pages){const c=Buffer.from(pg.ops.join('\n'),'latin1'),ci=add(Buffer.concat([Buffer.from(`<</Length ${c.length}>>\nstream\n`),c,Buffer.from('\nendstream')]));
  kids.push(add(`<</Type/Page/Parent 2 0 R/MediaBox[0 0 ${PW} ${pg.H}]/Resources<</Font<</F1 3 0 R/F2 4 0 R>>${img?`/XObject<</Im1 ${img} 0 R>>`:''}>>/Contents ${ci} 0 R>>`))}
 objs[1]=Buffer.from(`<</Type/Pages/Kids[${kids.map(k=>k+' 0 R').join(' ')}]/Count ${kids.length}>>`);
 let out=Buffer.from('%PDF-1.4\n'),offs=[];objs.forEach((o,i)=>{offs.push(out.length);out=Buffer.concat([out,Buffer.from(`${i+1} 0 obj\n`),o,Buffer.from('\nendobj\n')])});
 return Buffer.concat([out,Buffer.from(`xref\n0 ${objs.length+1}\n0000000000 65535 f \n`+offs.map(o=>String(o).padStart(10,'0')+' 00000 n \n').join('')+`trailer<</Size ${objs.length+1}/Root 1 0 R>>\nstartxref\n${out.length}\n%%EOF`)])};
// ---- Salida ESC/POS (directo a la impresora) ----
const CP850={'á':0xA0,'é':0x82,'í':0xA1,'ó':0xA2,'ú':0xA3,'ñ':0xA4,'Ñ':0xA5,'¿':0xA8,'¡':0xAD,'Á':0xB5,'É':0x90,'Í':0xD6,'Ó':0xE0,'Ú':0xE9,'ü':0x81,'Ü':0x9A,'»':0xAF,'«':0xAE,'·':0xFA};
const enc=(s,cp)=>Buffer.from([...String(s)].map(ch=>{const c=ch.charCodeAt(0);if(c<128)return c;if(cp=='1252')return c<256?c:63;return CP850[ch]??63}));
exports.escpos=(docs,cfg)=>{cfg=cfg||{};const B=[],put=(...a)=>B.push(Buffer.from(a.flat())),cp=String(cfg.codigo||'850');
 put(0x1b,0x40);put(0x1b,0x74,cp=='1252'?16:2);
 for(const d of docs){const{L,logo}=lineas(d,cfg);
  if(logo&&LOGO){put(0x1b,0x61,1);const bpr=LOGO.w/8,raw=Buffer.from(LOGO.data,'base64');for(let y=0;y<LOGO.h;y+=32){const h=Math.min(32,LOGO.h-y);put(0x1d,0x76,0x30,0,bpr&255,bpr>>8,h&255,h>>8);B.push(Buffer.from(raw.subarray(y*bpr,(y+h)*bpr).map(b=>~b&255)))}put(0x0a)}
  for(const l of L){put(0x1b,0x61,l.al=='c'?1:0);put(0x1b,0x45,l.b?1:0);put(0x1b,0x4d,l.sz=='s'?1:0);put(0x1d,0x21,l.sz=='d'?0x11:0);B.push(enc(l.t,cp));put(0x0a)}
  put(0x1b,0x45,0);put(0x1d,0x21,0);put(0x1b,0x61,0);put(0x1b,0x4d,0);put(0x1b,0x64,5);if(cfg.cortar)put(0x1d,0x56,1)}
 return Buffer.concat(B)};
