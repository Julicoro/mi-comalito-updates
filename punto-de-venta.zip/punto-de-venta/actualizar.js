// Actualizaciones del programa: descarga o recibe un .zip, lo valida, respalda el programa actual y lo reemplaza.
// NUNCA toca: datos.db, respaldos, config.json (ventas, copias y configuración).
const fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto'),{execFile}=require('child_process');
const RAIZ=__dirname,PROT=new Set(['datos.db','datos.db-wal','datos.db-shm','respaldos','config.json','node_modules','dist','.git','.vscode']);
const leerV=d=>{try{return JSON.parse(fs.readFileSync(path.join(d,'version.json'),'utf8'))}catch{return{}}};
const cmp=(a,b)=>{const x=String(a).split('.').map(Number),y=String(b).split('.').map(Number);for(let i=0;i<3;i++){const d=(x[i]||0)-(y[i]||0);if(d)return d>0?1:-1}return 0};
const sh=(cmd,args)=>new Promise((ok,no)=>execFile(cmd,args,{windowsHide:true,timeout:120000},(e,o,er)=>e?no(Error(String(er||e.message).trim().slice(0,300))):ok(o)));
const dirBk=()=>path.join(RAIZ,'respaldos','programa');
function copiar(de,a,saltar){fs.mkdirSync(a,{recursive:true});for(const e of fs.readdirSync(de,{withFileTypes:true})){if(saltar&&PROT.has(e.name))continue;const s=path.join(de,e.name),d=path.join(a,e.name);e.isDirectory()?copiar(s,d,false):fs.copyFileSync(s,d)}}
const lista=()=>fs.existsSync(dirBk())?fs.readdirSync(dirBk()).map(n=>({n,t:fs.statSync(path.join(dirBk(),n)).mtimeMs})).sort((a,b)=>b.t-a.t):[];
exports.version=()=>leerV(RAIZ).version||'0.0.0';
exports.hayAnterior=()=>lista().length>0;
exports.bajar=async(url,token)=>{let u;try{u=new URL(url)}catch{throw Error('La dirección de actualización no es válida.')}
 if(u.protocol!=='https:'&&!['localhost','127.0.0.1'].includes(u.hostname))throw Error('La dirección debe empezar con https://');
 try{const r=await fetch(url,{headers:token?{Authorization:'token '+token}:{},signal:AbortSignal.timeout(25000)});if(!r.ok)throw Error('No se pudo descargar ('+r.status+'). Revisa la dirección.');return Buffer.from(await r.arrayBuffer())}
 catch(e){if(e.message.startsWith('No se pudo descargar'))throw e;throw Error('No hay conexión a internet o la dirección no responde.')}};
exports.buscar=async(url,token)=>{if(!url)throw Error('Primero escribe la dirección de actualización y guárdala.');let j;
 try{j=JSON.parse((await exports.bajar(url,token)).toString('utf8'))}catch(e){if(e instanceof SyntaxError)throw Error('La dirección no devolvió un archivo version.json válido.');throw e}
 const actual=exports.version();return{actual,nueva:j.version,hay:cmp(j.version,actual)>0,notas:j.notas||'',zip:j.zip,sha256:j.sha256||'',fecha:j.fecha||''}};
exports.aplicar=async(buf,{sha256}={})=>{
 if(buf.length<4||buf.slice(0,2).toString()!=='PK')throw Error('El archivo no es un .zip válido.');
 if(sha256&&crypto.createHash('sha256').update(buf).digest('hex')!==String(sha256).toLowerCase())throw Error('El archivo descargado está dañado (no coincide). Intenta de nuevo.');
 const t=path.join(os.tmpdir(),'pv-upd-'+Date.now()),zip=t+'.zip';fs.writeFileSync(zip,buf);
 try{fs.mkdirSync(t,{recursive:true});
  if(process.platform==='win32')await sh('powershell',['-NoProfile','-Command',`Expand-Archive -LiteralPath '${zip.replace(/'/g,"''")}' -DestinationPath '${t.replace(/'/g,"''")}' -Force`]);else await sh('unzip',['-o','-q',zip,'-d',t]);
  const raiz=[t,...fs.readdirSync(t).map(x=>path.join(t,x))].find(d=>fs.existsSync(path.join(d,'server.js'))&&fs.existsSync(path.join(d,'public','caja.html')));
  if(!raiz)throw Error('Ese archivo no parece una actualización de este sistema.');
  await sh(process.execPath,['--check',path.join(raiz,'server.js')]).catch(()=>{throw Error('La actualización trae un error de programación y no se instaló. Tu sistema sigue igual.')});
  const ant=exports.version(),nv=leerV(raiz).version||ant,bk=path.join(dirBk(),`${ant}_${new Date().toISOString().slice(0,19).replace(/[:T]/g,'-')}`);
  copiar(RAIZ,bk,true);for(const o of lista().slice(3))fs.rmSync(path.join(dirBk(),o.n),{recursive:true,force:true});
  copiar(raiz,RAIZ,true);return{version:nv,anterior:ant}
 }finally{fs.rm(t,{recursive:true,force:true},()=>{});fs.unlink(zip,()=>{})}};
exports.revertir=()=>{const l=lista();if(!l.length)throw Error('No hay una versión anterior guardada.');const u=path.join(dirBk(),l[0].n);copiar(u,RAIZ,true);fs.rmSync(u,{recursive:true,force:true});return{version:exports.version()}};
