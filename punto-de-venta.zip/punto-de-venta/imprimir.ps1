# Envía bytes directos (RAW / ESC-POS) a una impresora de Windows.
param([string]$Impresora,[string]$Archivo)
$src=@"
using System;using System.Runtime.InteropServices;
public class RawPrn{
 [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Ansi)]public class DOCINFOA{[MarshalAs(UnmanagedType.LPStr)]public string pDocName;[MarshalAs(UnmanagedType.LPStr)]public string pOutputFile;[MarshalAs(UnmanagedType.LPStr)]public string pDataType;}
 [DllImport("winspool.Drv",EntryPoint="OpenPrinterA",SetLastError=true,CharSet=CharSet.Ansi,ExactSpelling=true,CallingConvention=CallingConvention.StdCall)]public static extern bool OpenPrinter([MarshalAs(UnmanagedType.LPStr)]string n,out IntPtr h,IntPtr d);
 [DllImport("winspool.Drv",EntryPoint="ClosePrinter",SetLastError=true,ExactSpelling=true,CallingConvention=CallingConvention.StdCall)]public static extern bool ClosePrinter(IntPtr h);
 [DllImport("winspool.Drv",EntryPoint="StartDocPrinterA",SetLastError=true,CharSet=CharSet.Ansi,ExactSpelling=true,CallingConvention=CallingConvention.StdCall)]public static extern bool StartDocPrinter(IntPtr h,Int32 level,[In,MarshalAs(UnmanagedType.LPStruct)]DOCINFOA di);
 [DllImport("winspool.Drv",EntryPoint="EndDocPrinter",SetLastError=true,ExactSpelling=true,CallingConvention=CallingConvention.StdCall)]public static extern bool EndDocPrinter(IntPtr h);
 [DllImport("winspool.Drv",EntryPoint="StartPagePrinter",SetLastError=true,ExactSpelling=true,CallingConvention=CallingConvention.StdCall)]public static extern bool StartPagePrinter(IntPtr h);
 [DllImport("winspool.Drv",EntryPoint="EndPagePrinter",SetLastError=true,ExactSpelling=true,CallingConvention=CallingConvention.StdCall)]public static extern bool EndPagePrinter(IntPtr h);
 [DllImport("winspool.Drv",EntryPoint="WritePrinter",SetLastError=true,ExactSpelling=true,CallingConvention=CallingConvention.StdCall)]public static extern bool WritePrinter(IntPtr h,IntPtr b,Int32 n,out Int32 w);
 public static string Send(string printer,byte[] data){IntPtr h;if(!OpenPrinter(printer,out h,IntPtr.Zero))return "No se pudo abrir la impresora '"+printer+"'. Revisa el nombre en Productos y mesas > Impresora.";
  var di=new DOCINFOA();di.pDocName="Ticket";di.pDataType="RAW";string r="OK";
  if(StartDocPrinter(h,1,di)){StartPagePrinter(h);IntPtr p=Marshal.AllocCoTaskMem(data.Length);Marshal.Copy(data,0,p,data.Length);Int32 w;if(!WritePrinter(h,p,data.Length,out w))r="La impresora no aceptó los datos.";Marshal.FreeCoTaskMem(p);EndPagePrinter(h);EndDocPrinter(h);}else r="No se pudo iniciar el trabajo de impresión.";
  ClosePrinter(h);return r;}
}
"@
Add-Type -TypeDefinition $src
if(-not $Impresora){$Impresora=(Get-CimInstance Win32_Printer | Where-Object {$_.Default}).Name}
[RawPrn]::Send($Impresora,[System.IO.File]::ReadAllBytes($Archivo))
